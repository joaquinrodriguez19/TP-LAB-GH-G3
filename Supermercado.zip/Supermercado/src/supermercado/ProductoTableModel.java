package supermercado;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;


public class ProductoTableModel extends AbstractTableModel {
    private List<Producto> productos;
    private String[] columnNames = {"Nombre", "Categoría", "Precio"};

    public ProductoTableModel() {
        this.productos = new ArrayList<>();
    }

    ProductoTableModel(List<Producto> productos) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    

    @Override
    public int getRowCount() {
        return productos.size();
    }

    @Override
    public int getColumnCount() {
        return columnNames.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Producto producto = productos.get(rowIndex);
        switch (columnIndex) {
            case 0: return producto.getNombre();
            case 1: return producto.getCategoria();
            case 2: return producto.getPrecio();
            default: return null;
        }
    }

    @Override
    public String getColumnName(int column) {
        return columnNames[column];
    }

    public void addProducto(Producto producto) {
        productos.add(producto);
        fireTableRowsInserted(productos.size() - 1, productos.size() - 1);
    }
   public void removeProducto(int row) {
    productos.remove(row);  
    fireTableRowsDeleted(row, row);
  }

    Object getProductos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setProductos(List<Producto> productosFiltrados) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setProductosFiltrados(List<Producto> productosFiltrados) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    Object getAllProductos() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

