package supermercado;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class SupermercadoFrame extends JFrame {
    private JTable tablaProductos;
    private JComboBox<String> comboCategorias;
    private JTextField txtNombre;
    private JTextField txtPrecio;
    private ProductoTableModel tableModel;

    public SupermercadoFrame() {
        setTitle("Supermercado DeTodo S.A.");
        setLayout(new BorderLayout());

        tableModel = new ProductoTableModel();
        tablaProductos = new JTable(tableModel);
        tablaProductos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaProductos.setDefaultEditor(Object.class, null); // Las celdas no son editables

        // MENU //
        JMenuBar menuBar = new JMenuBar();
        JMenu menuAdmin = new JMenu("Administración");
        JMenu menuConsultas = new JMenu("Consultas");

        JMenuItem menuItemGestion = new JMenuItem("Gestionar Productos");
        menuItemGestion.addActionListener(e -> mostrarPanelGestion());

        menuAdmin.add(menuItemGestion);
        menuBar.add(menuAdmin);
        menuBar.add(menuConsultas);

        setJMenuBar(menuBar);

        add(new JScrollPane(tablaProductos), BorderLayout.CENTER);
    }

    private void mostrarPanelGestion() {
        JPanel panelGestion = new JPanel();
        panelGestion.setLayout(new GridLayout(5, 2));  

        JLabel lblCategoria = new JLabel("Categoría:");
        JLabel lblNombre = new JLabel("Nombre:");
        JLabel lblPrecio = new JLabel("Precio:");

        comboCategorias = new JComboBox<>(new String[]{"Electrónica", "Ropa", "Alimentos" , "Comestibles" , "Limpieza" , "Perfumeria" , "Farmacia"});
        txtNombre = new JTextField();
        txtPrecio = new JTextField();

        JButton btnAgregar = new JButton("Agregar Producto");
        btnAgregar.addActionListener(e -> agregarProducto());

        JButton btnEliminar = new JButton("Eliminar Producto");  // Botón para eliminar productos
        btnEliminar.addActionListener(e -> eliminarProducto());

        panelGestion.add(lblCategoria);
        panelGestion.add(comboCategorias);
        panelGestion.add(lblNombre);
        panelGestion.add(txtNombre);
        panelGestion.add(lblPrecio);
        panelGestion.add(txtPrecio);
        panelGestion.add(btnAgregar);
        panelGestion.add(btnEliminar);  

        JFrame gestionFrame = new JFrame("Gestión de Productos");
        gestionFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        gestionFrame.setSize(400, 300);
        gestionFrame.add(panelGestion);
        gestionFrame.setVisible(true);
    }

    private void agregarProducto() {
        String categoria = (String) comboCategorias.getSelectedItem();
        String nombre = txtNombre.getText();
        String precioTexto = txtPrecio.getText();

        if (nombre.isEmpty() || precioTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos deben ser llenados.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double precio;
        try {
            precio = Double.parseDouble(precioTexto);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El precio debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Producto producto = new Producto(nombre, categoria, precio);
        tableModel.addProducto(producto);
    }

    private void eliminarProducto() {
        int selectedRow = tablaProductos.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Debe seleccionar un producto para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea eliminar el producto?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            tableModel.removeProducto(selectedRow);  // Elimina el producto de la tabla y el modelo
        }
    }

    public static void main(String[] args) {
        new SupermercadoFrame();
    }
}