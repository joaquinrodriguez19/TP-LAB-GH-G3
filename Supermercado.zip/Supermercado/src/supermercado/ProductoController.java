
package supermercado;

import java.util.TreeSet;

public class ProductoController {
    private TreeSet<Producto> productos;

    public ProductoController() {
        this.productos = new TreeSet<>();
    }

    public void addProducto(Producto producto) {
        productos.add(producto);
    }

    public void removeProducto(int codigo) {
        productos.removeIf(p -> p.getCodigo() == codigo);
    }

    public void updateProducto(Producto producto) {
        removeProducto(producto.getCodigo());
        addProducto(producto);
    }

    public TreeSet<Producto> getProductos() {
        return productos;
    }
}