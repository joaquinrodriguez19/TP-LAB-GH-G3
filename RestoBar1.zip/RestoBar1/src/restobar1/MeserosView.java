
package restobar1;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

class MeserosView extends JInternalFrame {
    private JTextField txtIdMesero, txtNombre, txtDNI;
    private JTable tableMeseros;
    
    public MeserosView() {
        super("Gestión de Meseros", true, true, true, true);
        setSize(400, 300);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        JPanel panelForm = new JPanel();
        panelForm.add(new JLabel("ID Mesero:"));
        txtIdMesero = new JTextField(10);
        panelForm.add(txtIdMesero);
        
        panelForm.add(new JLabel("Nombre:"));
        txtNombre = new JTextField(10);
        panelForm.add(txtNombre);
        
      
        
        add(panelForm);

        // Botones de ABMC
        JPanel panelBotones = new JPanel();
        JButton btnAlta = new JButton("Alta");
        JButton btnBaja = new JButton("Baja");
        JButton btnModificar = new JButton("Modificar");
        JButton btnConsultar = new JButton("Consultar");

        panelBotones.add(btnAlta);
        panelBotones.add(btnBaja);
        panelBotones.add(btnModificar);
        panelBotones.add(btnConsultar);

        add(panelBotones);
        
        // Tabla para mostrar meseros
        String[] columnas = {"ID", "Nombre",};
        Object[][] data = {}; // Datos de ejemplo vacíos
        tableMeseros = new JTable(data, columnas);
        JScrollPane scrollPane = new JScrollPane(tableMeseros);
        add(scrollPane);
        
        
        
        
    }
}
