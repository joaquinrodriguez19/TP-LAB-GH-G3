
package restobar1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame {
    
    private JDesktopPane desktopPane;

    public MainFrame() {
        setTitle("Sistema de Restaurante");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Crear el menu principal
        JMenuBar menuBar = new JMenuBar();
        
        // Menú Meseros
        JMenu menuMeseros = new JMenu("Meseros");
        JMenuItem menuItemMesero = new JMenuItem("Gestionar Meseros");
        menuItemMesero.addActionListener(e -> openMeserosView());
        JMenuItem menuItemAgregarMesero = new JMenuItem("Agregar Mesero");
        menuItemAgregarMesero.addActionListener(e -> agregarMesero());
        menuMeseros.add(menuItemMesero);
        menuMeseros.add(menuItemAgregarMesero);
        
        // Menu Mesas
        JMenu menuMesas = new JMenu("Mesas");
        JMenuItem menuItemMesas = new JMenuItem("Gestionar Mesas");
        menuItemMesas.addActionListener(e -> openMesasView());
        JMenuItem menuItemAgregarMesa = new JMenuItem("Agregar Mesa");
        menuItemAgregarMesa.addActionListener(e -> agregarMesa());
        menuMesas.add(menuItemMesas);
        menuMesas.add(menuItemAgregarMesa);

        // Menu Pedidos
        JMenu menuPedidos = new JMenu("Pedidos");
        JMenuItem menuItemNuevoPedido = new JMenuItem("Nuevo Pedido");
        menuItemNuevoPedido.addActionListener(e -> openPedidoView());
        menuPedidos.add(menuItemNuevoPedido);
        
        // Añadir menús al menu principal
        menuBar.add(menuMeseros);
        menuBar.add(menuMesas);
        menuBar.add(menuPedidos);
        
        setJMenuBar(menuBar);
        
        // Desktop Pane para ventanas internas
        desktopPane = new JDesktopPane();
        add(desktopPane);
    }

    // Métodos para abrir las ventanas internas
    private void openMeserosView() {
        MeserosView meserosView = new MeserosView();
        desktopPane.add(meserosView);
        meserosView.setVisible(true);
    }
    
    private void openMesasView() {
        MeserosView mesasView = new MeserosView();
        desktopPane.add(mesasView);
        mesasView.setVisible(true);
    }

    private void openPedidoView() {
        PedidoView pedidoView = new PedidoView();
        desktopPane.add(pedidoView);
        pedidoView.setVisible(true);
    }

    // Metodos para agregar Mesero y Mesa
    private void agregarMesero() {
        String nombreMesero = JOptionPane.showInputDialog(this, "Ingrese el nombre del mesero:");
        if (nombreMesero != null && !nombreMesero.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mesero '" + nombreMesero + "' agregado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Nombre de mesero no válido.");
        }
    }

    private void agregarMesa() {
        String numeroMesa = JOptionPane.showInputDialog(this, "Ingrese el número de la mesa:");
        if (numeroMesa != null && !numeroMesa.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mesa '" + numeroMesa + "' agregada correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Número de mesa no válido.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MainFrame mainFrame = new MainFrame();
            mainFrame.setVisible(true);
        });
    }
}

// Clase PedidoView para gestionar pedidos
class PedidoView extends JInternalFrame {
    private JComboBox<String> comboProducto;
    private JTextField txtCantidad;
    private JTextArea areaPedido;
    private JLabel lblTotal;
    private double totalPedido = 0.0;

    public PedidoView() {
        setTitle("Nuevo Pedido");
        setSize(400, 300);
        setClosable(true);
        setLayout(new FlowLayout());

        // Productos disponibles (ejemplo)
        String[] productos = {"Pizza Muzza - $9000", "Fideos con Osobuco - $13500", "Empanadas (Media Docena) - $7000", "Coca Vidrio 500ml - $3000"};
        comboProducto = new JComboBox<>(productos);
        add(new JLabel("Producto:"));
        add(comboProducto);

        // Campo de texto para la cantidad
        add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField(5);
        add(txtCantidad);

        // Área para mostrar el pedido
        areaPedido = new JTextArea(10, 30);
        areaPedido.setEditable(false);
        add(new JScrollPane(areaPedido));

        // Botón para agregar al pedido
        JButton btnAgregar = new JButton("Agregar al Pedido");
        btnAgregar.addActionListener(e -> agregarProducto());
        add(btnAgregar);

        // Total del pedido
        lblTotal = new JLabel("Total: $0.00");
        add(lblTotal);
    }

    // Método para agregar productos al pedido
    private void agregarProducto() {
        String producto = (String) comboProducto.getSelectedItem();
        String cantidadStr = txtCantidad.getText();

        try {
            int cantidad = Integer.parseInt(cantidadStr);
            double precio = obtenerPrecioProducto(producto);
            double subtotal = precio * cantidad;
            totalPedido += subtotal;

            // Actualizar área de pedido y total
            areaPedido.append(producto + " x" + cantidad + " - $" + subtotal + "\n");
            lblTotal.setText("Total: $" + String.format("%.2f", totalPedido));
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Por favor, ingrese una cantidad válida.");
        }
    }

    // Método para obtener el precio del producto seleccionado
    private double obtenerPrecioProducto(String producto) {
        if (producto.contains("Pizza Muzza")) return 9000.0;
        if (producto.contains("Fideos con Osobuco")) return 13500.0;
        if (producto.contains("Empanadas")) return 7000.0;
        if (producto.contains("Coca Vidrio")) return 3000.0;
        return 0.0;
    }
}
