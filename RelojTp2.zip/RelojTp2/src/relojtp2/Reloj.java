
package relojtp2;
import java.time.LocalDate;

public class Reloj {
    private LocalDate fecha;

    public Reloj() {
        this.fecha = LocalDate.now();
    }

    public void mostrarFecha() {
        System.out.println("La fecha actual es: " + fecha);
    }
}