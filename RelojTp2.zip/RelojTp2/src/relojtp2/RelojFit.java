
package relojtp2;

public class RelojFit extends Reloj {
    private int pasos;

    public RelojFit() {
        super();
        this.pasos = 1;
    }

    public void cuentaPasos(int x, int y) {
        // Logic for counting steps based on coordinates (can be enhanced)
        pasos++;
        System.out.println("Pasos: " + pasos);
    }

    public void frecuenciaAleatoria() {
        int frecuencia = (int) (Math.random() * 100 + 60);
        System.out.println("Frecuencia cardiaca: " + frecuencia + " ppm");
    }
}
