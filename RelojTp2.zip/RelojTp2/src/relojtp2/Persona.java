
package relojtp2;

public class Persona {
    private String nombre;
    RelojFit reloj; // Create a RelojFit object directly

    public Persona(String nombre) {
        this.nombre = nombre;
        this.reloj = new RelojFit();
    }

    public void mostrarInformacion() {
        System.out.println("Nombre: " + nombre);
        reloj.mostrarFecha(); // Access methods of RelojFit directly
    }
}