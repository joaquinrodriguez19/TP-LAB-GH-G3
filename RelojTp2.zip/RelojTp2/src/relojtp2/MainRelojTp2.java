
package relojtp2;

public class MainRelojTp2 {
public static void main(String[] args) {
        Persona unaPersona = new Persona("Juan");
        unaPersona.mostrarInformacion();

        // No casting needed, directly call RelojFit methods
        unaPersona.reloj.cuentaPasos(10, 20);
        unaPersona.reloj.frecuenciaAleatoria();
    }
    
}

   