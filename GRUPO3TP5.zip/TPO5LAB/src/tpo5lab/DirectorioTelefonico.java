
package tpo5lab;

import java.util.*;

public class DirectorioTelefonico {
    private TreeMap<Long, Contacto> contactos;

    public DirectorioTelefonico() {
        this.contactos = new TreeMap<>();
    }

    // A. agregarContacto
    public void agregarContacto(Long telefono, Contacto contacto) {
        contactos.put(telefono, contacto);
    }


    public Contacto buscarContacto(Long telefono) {
        return contactos.get(telefono);
    }


    public Set<Long> buscarTelefono(String apellido) {
        Set<Long> telefonos = new TreeSet<>();
        for (Map.Entry<Long, Contacto> entry : contactos.entrySet()) {
            if (entry.getValue().getApellido().equalsIgnoreCase(apellido)) {
                telefonos.add(entry.getKey());
            }
        }
        return telefonos;
    }

    
    public ArrayList<Contacto> buscarContactos(String ciudad) {
        ArrayList<Contacto> listaContactos = new ArrayList<>();
        for (Contacto contacto : contactos.values()) {
            if (contacto.getCiudad().equalsIgnoreCase(ciudad)) {
                listaContactos.add(contacto);
            }
        }
        return listaContactos;
    }

    // E. borrarContacto
    public void borrarContacto(Long telefono) {
        contactos.remove(telefono);
    }
}