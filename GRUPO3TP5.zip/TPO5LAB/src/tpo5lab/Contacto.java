
package tpo5lab;

public class Contacto {
    private String DNI;
    private String nombre;
    private String apellido;
    private String ciudad;
    private String direccion;

    public Contacto(String DNI, String nombre, String apellido, String ciudad, String direccion) {
        this.DNI = DNI;
        this.nombre = nombre;
        this.apellido = apellido;
        this.ciudad = ciudad;
        this.direccion = direccion;
    }

    public String getDNI() {
        return DNI;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getCiudad() {
        return ciudad;
    }

    public String getDireccion() {
        return direccion;
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " - " + ciudad + " (" + DNI + ")";
    }
}
