
package tpo5lab;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Set;

public class FormularioContacto extends JFrame {
    private DirectorioTelefonico directorio;
    
    
    private JTextField txtDNI, txtNombre, txtApellido, txtCiudad, txtDireccion, txtTelefono;
    private JTextArea areaResultados;
    
    public FormularioContacto() {
        directorio = new DirectorioTelefonico();
        
        setTitle("Directorio Telefónico");
        setSize(400, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
        
        
        JPanel panelFormulario = new JPanel(new GridLayout(7, 2));
        panelFormulario.add(new JLabel("DNI:"));
        txtDNI = new JTextField();
        panelFormulario.add(txtDNI);
        
        panelFormulario.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelFormulario.add(txtNombre);
        
        panelFormulario.add(new JLabel("Apellido:"));
        txtApellido = new JTextField();
        panelFormulario.add(txtApellido);
        
        panelFormulario.add(new JLabel("Ciudad:"));
        txtCiudad = new JTextField();
        panelFormulario.add(txtCiudad);
        
        panelFormulario.add(new JLabel("Dirección:"));
        txtDireccion = new JTextField();
        panelFormulario.add(txtDireccion);
        
        panelFormulario.add(new JLabel("Teléfono:"));
        txtTelefono = new JTextField();
        panelFormulario.add(txtTelefono);
        
        JButton btnAgregar = new JButton("Agregar Contacto");
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarContacto();
            }
        });
        panelFormulario.add(btnAgregar);
        
        add(panelFormulario, BorderLayout.NORTH);
        
        // Panel central - Resultados
        areaResultados = new JTextArea(15, 30);
        areaResultados.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(areaResultados);
        add(scrollPane, BorderLayout.CENTER);
        
        // Panel inferior - Botones de búsqueda y eliminación
        JPanel panelBotones = new JPanel(new GridLayout(2, 1));
        
        JButton btnBuscarTelefono = new JButton("Buscar Contacto por Teléfono");
        btnBuscarTelefono.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarContactoPorTelefono();
            }
        });
        panelBotones.add(btnBuscarTelefono);
        
        JButton btnEliminarContacto = new JButton("Eliminar Contacto");
        btnEliminarContacto.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarContacto();
            }
        });
        panelBotones.add(btnEliminarContacto);
        
        add(panelBotones, BorderLayout.SOUTH);
    }
    
    
    private void agregarContacto() {
        try {
            String dni = txtDNI.getText();
            String nombre = txtNombre.getText();
            String apellido = txtApellido.getText();
            String ciudad = txtCiudad.getText();
            String direccion = txtDireccion.getText();
            Long telefono = Long.parseLong(txtTelefono.getText());
            
            Contacto contacto = new Contacto(dni, nombre, apellido, ciudad, direccion);
            directorio.agregarContacto(telefono, contacto);
            
            areaResultados.append("Contacto agregado: " + contacto + "\n");
            
        
            txtDNI.setText("");
            txtNombre.setText("");
            txtApellido.setText("");
            txtCiudad.setText("");
            txtDireccion.setText("");
            txtTelefono.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un número de teléfono válido.");
        }
    }
    
   
    private void buscarContactoPorTelefono() {
        try {
            Long telefono = Long.parseLong(JOptionPane.showInputDialog(this, "Ingrese el número de teléfono:"));
            Contacto contacto = directorio.buscarContacto(telefono);
            
            if (contacto != null) {
                areaResultados.append("Contacto encontrado: " + contacto + "\n");
            } else {
                areaResultados.append("No se encontró un contacto con el teléfono: " + telefono + "\n");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un número de teléfono válido.");
        }
    }
    
  
    private void eliminarContacto() {
        try {
            Long telefono = Long.parseLong(JOptionPane.showInputDialog(this, "Ingrese el número de teléfono a eliminar:"));
            directorio.borrarContacto(telefono);
            areaResultados.append("Contacto con teléfono " + telefono + " eliminado.\n");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa un número de teléfono válido.");
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            FormularioContacto formulario = new FormularioContacto();
            formulario.setVisible(true);
        });
    }
}
